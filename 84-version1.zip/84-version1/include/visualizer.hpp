#ifndef VISUALIZER_HPP
#define VISUALIZER_HPP

#include <SFML/Graphics.hpp>

void runSFMLVisualization();
//void drawPositionSFML(sf::RenderWindow& window, const std::vector<Ant>& ants, int grid_size, const std::vector<std::shared_ptr<Node>>& nodes)

#endif /* VISUALIZER_HPP */
